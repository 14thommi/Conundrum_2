# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
prepared = dataiku.Dataset("prepared")
prepared_df = prepared.get_dataframe()




# Write recipe outputs
eda_Analysis = dataiku.Folder("zGSGyoti")
eda_Analysis_info = eda_Analysis.get_info()
