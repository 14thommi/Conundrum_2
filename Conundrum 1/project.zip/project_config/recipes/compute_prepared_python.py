# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu
import math

# Read recipe inputs
prepared = dataiku.Dataset("prepared")
prepared_df = prepared.get_dataframe()

# Compute recipe outputs from inputs
# TODO: Replace this part by your actual code that computes the output, as a Pandas dataframe
# NB: DSS also supports other kinds of APIs for reading and writing data. Please see doc.
prepared_python_df = prepared_df # For this sample code, simply copy input to output

# Write recipe outputs
prepared_python = dataiku.Dataset("prepared_python")
prepared_python.write_with_schema(prepared_python_df)
